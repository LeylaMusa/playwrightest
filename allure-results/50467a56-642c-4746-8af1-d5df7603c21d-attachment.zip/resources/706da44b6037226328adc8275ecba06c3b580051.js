document.addEventListener('DOMContentLoaded', () => {
  function setTrackColors(el) {
    const value = el.value;
    const min = el.min || 0;
    const max = el.max || 100;
    const percent = ((value - min) / (max - min)) * 100;

    el.style.background = `linear-gradient(to right, rgba(96, 65, 211, 1) ${percent}%, white ${percent}%)`;
  }

  function isMobileDevice() {
    return window.innerWidth > 767;
  }

  const dataStoredChart = document.getElementById('dataStoredChart');
  const tbStored = document.getElementById('tbStored');
  const dataStoredInput = document.getElementById('dataStoredInput');

  const rabataMobile = document.getElementById('rabataMobile');
  const azureMobile = document.getElementById('azureMobile');
  const amazonMobile = document.getElementById('amazonMobile');
  const googleMobile = document.getElementById('googleMobile');

  tbStored.innerHTML = dataStoredInput.value;

  let rabataStored = (Math.floor(dataStoredInput.value / 10 - 0.01) + 1) * 59 * 12;
  let azureStored = (Math.floor(dataStoredInput.value / 10 - 0.01) + 1) * 208 * 12;
  let amazonStored = (Math.floor(dataStoredInput.value / 10 - 0.01) + 1) * 260 * 12;
  let googleStored = (Math.floor(dataStoredInput.value / 10 - 0.01) + 1) * 230 * 12;
  let rounded = amazonStored + amazonStored * 0.2;

  rabataMobile.innerHTML = '$' + rabataStored + ' / yr';
  azureMobile.innerHTML = '$' + azureStored + ' / yr';
  amazonMobile.innerHTML = '$' + amazonStored + ' / yr';
  googleMobile.innerHTML = '$' + googleStored + ' / yr';

  dataStoredInput.addEventListener('input', function () {
    setTrackColors(this);
    tbStored.innerHTML = dataStoredInput.value;

    rabataStored = (Math.floor(dataStoredInput.value / 10 - 0.01) + 1) * 59 * 12;
    azureStored = (Math.floor(dataStoredInput.value / 10 - 0.01) + 1) * 208 * 12;
    amazonStored = (Math.floor(dataStoredInput.value / 10 - 0.01) + 1) * 260 * 12;
    googleStored = (Math.floor(dataStoredInput.value / 10 - 0.01) + 1) * 230 * 12;
    chart.data.datasets.forEach((dataset) => {
      dataset.data = [rabataStored, azureStored, amazonStored, googleStored];
    });
    rounded = amazonStored + amazonStored * 0.2;
    chart.options.scales.yAxes[0].ticks.max = Math.round(rounded / 1000) * 1000;
    chart.update();

    rabataMobile.innerHTML = '$' + rabataStored + ' / yr';
    azureMobile.innerHTML = '$' + azureStored + ' / yr';
    amazonMobile.innerHTML = '$' + amazonStored + ' / yr';
    googleMobile.innerHTML = '$' + googleStored + ' / yr';
  });

  setTrackColors(dataStoredInput);
  dataStoredInput.style.borderRadius = '5px';

  let chart = new Chart(dataStoredChart, {
    type: 'bar',
    data: {
      labels: ['Rabata Cloud Storage', 'Microsoft Azure', 'Amazon S3', 'Google Cloud'],
      datasets: [{
        data: [rabataStored, azureStored, amazonStored, googleStored],
        borderWidth: 1,
        barRadius: 10, // Set the border radius value
        backgroundColor: [
          'rgba(96, 65, 211, 1)',
          'rgba(176, 170, 245, 1)',
          'rgba(176, 170, 245, 1)',
          'rgba(176, 170, 245, 1)',
        ],
        datalabels: {
          color: '#FFCE56',
        },
      }],
    },
    options: {
      legend: {
        display: false,
      },
      tooltips: {
        enabled: false,
      },
      'hover': {
        mode: null,
        'animationDuration': 0,
      },
      'animation': {
        'duration': 1,
        'onComplete': function () {
          const chartInstance = this.chart;
          const ctx = chartInstance.ctx;

          ctx.font = '16px Gilroy';
          ctx.fillStyle = 'rgba(176, 170, 245, 1)';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'bottom';
          this.data.datasets.forEach(function (dataset, i) {
            let meta = chartInstance.controller.getDatasetMeta(i);

            if (isMobileDevice()) {
              meta.data.forEach(function (bar, index) {
                let data = '$' + dataset.data[index] + ' / yr';
                ctx.fillText(data, bar._model.x, bar._model.y - 15);
              });
            }
          });
        },
      },
      scales: {
        xAxes: [{
          ticks: {
            fontColor: 'rgba(176, 170, 245, 1)',
            fontSize: '14',
            display: isMobileDevice(),
          },
        }],
        yAxes: [{
          ticks: {
            fontColor: 'rgba(210, 210, 210, 1)',
            fontSize: '16',
            stepSize: rounded * 2,
            max: Math.round(rounded / 1000) * 1000,
          },
        }],
      },
    },
  });

  function redrawChart() {
    chart.options.scales.xAxes[0].display = isMobileDevice();
    chart.options.scales.xAxes[0].ticks.display = isMobileDevice();

    chart.options.scales.yAxes[0].display = !isMobileDevice();
    chart.options.scales.yAxes[0].ticks.display = !isMobileDevice();

    chart.resize();
    chart.update();
  }

  redrawChart();

  window.addEventListener('resize', redrawChart);
});
