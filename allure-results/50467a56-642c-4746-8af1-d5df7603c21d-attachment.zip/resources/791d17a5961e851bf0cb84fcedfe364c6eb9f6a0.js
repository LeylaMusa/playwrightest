class Modal {
  constructor(modalContainerId, callback) {
    this.modal = $(modalContainerId);
    this.callback = callback;
    this.selectors = {
      modalCloseButton: '.modal-close-btn',
      callBackTrigger: '.js-modal-callback-trigger',
    };
    this.callbackParams = {};

    this.init();
  }

  show(message) {
    let messageBox = this.modal.find('.message');

    if (messageBox && messageBox.data('default-message')) {
      messageBox.text(messageBox.data('default-message'));
    }

    if (message) {
      messageBox.text(message);
    }

    this.modal.removeClass('is-hidden');
  }

  hide() {
    this.modal.addClass('is-hidden');
  }

  showConfirm(id) {
    this.callbackParams.id = id;

    this.show();
  }

  bindEvents() {
    $(document).on('keydown', (event) => {
      if (event.key === 'Escape') {
        this.hide();
      }
    });

    this.modal.on('click', (event) => {
      if (
        event.target.id === this.modal.attr('id')
        && 'modalCreateAccessKeyResult' !== event.target.id
      ) {
        this.hide();
      }
    });

    this.modal.find(this.selectors.modalCloseButton).on('click', () => {
      this.hide();
    });

    this.modal.find(this.selectors.callBackTrigger).on('click', () => {
      if (this.callback) {
        this.callback();
      }
    });
  }

  init() {
    this.bindEvents();
  }
}

let modalSuccess;
let modalError;
let modalWarning;
let modalPrivacy;
let modalTerms;
let modalNotification;
let modalCreateAccessKeyResult;
let modalCreateAccessKeyStep1;
let modalChooseBucketTariff;
let modalCreateBucket;
let modalDeleteAccessKey;
let modalDeleteBucket;
let modalShowDetails;
let modalAddNewCard;
let modalUserSettingsUpdate;
let modalResetPasswordForm;
let modalResetPasswordSuccessMessage;

$(function() {
  modalSuccess = new Modal('#modalSuccessRequest');
  modalError = new Modal('#modalErrorRequest');
  modalWarning = new Modal('#modalWarningRequest');
  modalPrivacy = new Modal('#modalPrivacy');
  modalTerms = new Modal('#modalTerms');
  modalNotification = new Modal('#modalNotificationItem');
  modalCreateAccessKeyResult = new Modal('#modalCreateAccessKeyResult');
  modalCreateAccessKeyStep1 = new Modal('#modalCreateAccessKeyStep1');
  modalCreateBucket = new Modal('#modalCreateBucket');
  modalShowDetails = new Modal('#modalShowDetails');
  modalAddNewCard = new Modal('#modalAddNewCard');
  modalUserSettingsUpdate = new Modal('#modalUserSettingsUpdate');
  modalResetPasswordForm = new Modal('#modalResetPasswordForm');
  modalResetPasswordSuccessMessage = new Modal('#modalResetPasswordSuccessMessage');

  modalDeleteAccessKey = new Modal('#modalDeleteAccessKey', function () {
    const form = this.modal.find('#deleteAccessKeyForm');
    const apiKey = this.callbackParams.id;

    form.find('[data-bind-value="apiKey"]').val(apiKey);

    this.modal.find(this.selectors.callBackTrigger).attr('disabled', true);
    this.modal.find(this.selectors.callBackTrigger).addClass('btn-disabled is-loading');

    form.trigger('submit');
  });

  modalDeleteBucket = new Modal('#modalDeleteBucket', function () {
    const form = this.modal.find('#deleteBucketForm');
    const bucketName = this.callbackParams.id;

    form.find('[data-bind-value="bucketName"]').val(bucketName);

    this.modal.find(this.selectors.callBackTrigger).attr('disabled', true);
    this.modal.find(this.selectors.callBackTrigger).addClass('btn-disabled is-loading');

    form.trigger('submit');
  });

  modalChooseBucketTariff = new Modal('#modalChooseBucketTariff', function () {
    const tariffId = this.modal.find('input[type="radio"]:checked').attr('value');
    const tariffTitle = this.modal.find('input[type="radio"]:checked').attr('title');

    this.hide();

    $('[data-bind-value="tariffId"]').val(tariffId);

    if ('Backup' === tariffTitle) {
      $('.newBucketAcl').hide();
    } else {
      $('.newBucketAcl').show();
    }

    modalCreateBucket.show();
  });
});
