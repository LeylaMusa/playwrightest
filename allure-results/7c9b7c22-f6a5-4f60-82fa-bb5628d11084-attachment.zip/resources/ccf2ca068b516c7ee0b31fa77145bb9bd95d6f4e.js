document.addEventListener('DOMContentLoaded', () => {
  let backupBtn = document.getElementById('tariffBtn_1');
  let apiBtn = document.getElementById('tariffBtn_0');

  let backupTable = document.getElementById('backupTable');
  let apiTable = document.getElementById('apiTable');

  let sendEmailVerificationAgain = document.getElementById('resend-notification');

  let showSettingsFormButton = document.getElementById('showSettingsFormButton');

  showSettingsFormButton && showSettingsFormButton.addEventListener('click', () => {
    if (modalUserSettingsUpdate) {
      modalUserSettingsUpdate.modal.find('[data-default-value]').each(function() {
        $(this).val($(this).data('default-value'));
      });

      let validator = modalUserSettingsUpdate.modal.find('form').data('validator');
      validator.setFormFields();

      modalUserSettingsUpdate.modal.find('.is-error').removeClass('is-error');

      modalUserSettingsUpdate.show();

    }
  });

  sendEmailVerificationAgain && sendEmailVerificationAgain.addEventListener('click', () => {
    $.post(
      '/api/user/send-email-verification',
      JSON.stringify({}),
      function(response) {
        if (response.status) {
          modalSuccess.show();
        } else {
          modalError.show();
        }
      },
      'json',
    );
  });

  backupBtn && backupBtn.addEventListener('click', () => {
    apiTable.style.display = 'none';
    backupTable.style.display = 'block';
  });

  apiBtn && apiBtn.addEventListener('click', () => {
    backupTable.style.display = 'none';
    apiTable.style.display = 'block';
  });

  $('.trim-secret').click(function () {
    $(this).removeClass('trim-secret');
    $(this).addClass('trim-secret-visible');
  });

  $('.copy-host').click(function () {
    if (navigator.clipboard) {
      navigator.clipboard.writeText($(this).data('host'));
      let info = $(this).find('i');
      info.text(TRANSLATIONS.en.copied);

      setTimeout(() => info.text(''), 2000);
    }
  });

  $('.change-acl').click(function () {
    let bucketId = $(this).data('id');
    let acl = $(this).data('acl');
    let title = $(this).data('title');

    $.post(
      '/api/bucket-acl',
      JSON.stringify({
        'id': bucketId,
        'acl': acl,
      }),
      function(response) {
        if (response.status) {
          $('.acl-' + bucketId).html(title);
          $('.change-acl.bucket-' + bucketId).removeClass('hidden');
          $('.change-acl.bucket-' + bucketId + '[data-acl=' + acl + ']').addClass('hidden');

          modalSuccess.show(response.message);
        } else {
          modalError.show(response.message);
        }
      },
      'json',
    );
  });

  function isMobileDevice() {
    return window.innerWidth > 767;
  }

  function setTrackColors(el) {
    const value = el.value;
    const min = el.min || 0;
    const max = el.max || 100;
    const percent = ((value - min) / (max - min)) * 100;

    el.style.background = `linear-gradient(to right, rgba(96, 65, 211, 1) ${percent}%, white ${percent}%)`;
  }

  const dataApiStoredInput = document.getElementById('dataApiStoredInput');
  if (dataApiStoredInput) {
    const dataApiChart = document.getElementById('dataApiChart');
    const tbApiStored = document.getElementById('tbApiStored');
    const tbDownload = document.getElementById('tbDownload');
    const dataDownloadInput = document.getElementById('dataDownloadInput');

    const rabataMobileApi = document.getElementById('rabataMobileApi');
    const azureMobileApi = document.getElementById('azureMobileApi');
    const amazonMobileApi = document.getElementById('amazonMobileApi');
    const googleMobileApi = document.getElementById('googleMobileApi');

    tbApiStored.innerHTML = dataApiStoredInput.value;
    tbDownload.innerHTML = dataDownloadInput.value;

    let rabataStoredApi = 18 * (1000 * dataApiStoredInput.value + 1000 * dataDownloadInput.value) / 100;
    let azureStoredApi = 12 * 2.1 * (1000 * dataApiStoredInput.value + 1000 * dataDownloadInput.value) / 100;
    let amazonStoredApi = 12 * 2.5 * (1000 * dataApiStoredInput.value + 1000 * dataDownloadInput.value) / 100;
    let googleStoredApi = 12 * 3.1 * (1000 * dataApiStoredInput.value + 1000 * dataDownloadInput.value) / 100;
    let roundedApi = amazonStoredApi + amazonStoredApi * 0.2;

    rabataMobileApi.innerHTML = '$' + Math.floor(rabataStoredApi) + ' / yr';
    azureMobileApi.innerHTML = '$' + Math.floor(azureStoredApi) + ' / yr';
    amazonMobileApi.innerHTML = '$' + Math.floor(amazonStoredApi) + ' / yr';
    googleMobileApi.innerHTML = '$' + Math.floor(googleStoredApi) + ' / yr';

    dataApiStoredInput.addEventListener('input', function () {
      setTrackColors(this);
      tbApiStored.innerHTML = dataApiStoredInput.value;

      let rabataStoredApi = 18 * (1000 * dataApiStoredInput.value + 1000 * dataDownloadInput.value) / 100;
      let azureStoredApi = 12 * 2.1 * (1000 * dataApiStoredInput.value + 1000 * dataDownloadInput.value) / 100;
      let amazonStoredApi = 12 * 2.5 * (1000 * dataApiStoredInput.value + 1000 * dataDownloadInput.value) / 100;
      let googleStoredApi = 12 * 3.1 * (1000 * dataApiStoredInput.value + 1000 * dataDownloadInput.value) / 100;

      chartApi.data.datasets.forEach((dataset) => {
        dataset.data = [Math.floor(rabataStoredApi), Math.floor(azureStoredApi), Math.floor(amazonStoredApi), Math.floor(googleStoredApi)];
      });
      roundedApi = amazonStoredApi + amazonStoredApi * 0.2;

      chartApi.options.scales.yAxes[0].ticks.max = roundedApi * 1.5;
      chartApi.update();

      rabataMobileApi.innerHTML = '$' + Math.floor(rabataStoredApi) + ' / yr';
      azureMobileApi.innerHTML = '$' + Math.floor(azureStoredApi) + ' / yr';
      amazonMobileApi.innerHTML = '$' + Math.floor(amazonStoredApi) + ' / yr';
      googleMobileApi.innerHTML = '$' + Math.floor(googleStoredApi) + ' / yr';
    });

    dataDownloadInput.addEventListener('input', function () {
      setTrackColors(this);
      tbDownload.innerHTML = dataDownloadInput.value;

      let rabataStoredApi = 18 * (1000 * dataApiStoredInput.value + 1000 * dataDownloadInput.value) / 100;
      let azureStoredApi = 12 * 2.1 * (1000 * dataApiStoredInput.value + 1000 * dataDownloadInput.value) / 100;
      let amazonStoredApi = 12 * 2.5 * (1000 * dataApiStoredInput.value + 1000 * dataDownloadInput.value) / 100;
      let googleStoredApi = 12 * 3.1 * (1000 * dataApiStoredInput.value + 1000 * dataDownloadInput.value) / 100;

      chartApi.data.datasets.forEach((dataset) => {
        dataset.data = [Math.floor(rabataStoredApi), Math.floor(azureStoredApi), Math.floor(amazonStoredApi), Math.floor(googleStoredApi)];

      });
      roundedApi = amazonStoredApi + amazonStoredApi * 0.2;

      chartApi.options.scales.yAxes[0].ticks.max = roundedApi * 1.5;
      chartApi.update();

      rabataMobileApi.innerHTML = '$' + Math.floor(rabataStoredApi) + ' / yr';
      azureMobileApi.innerHTML = '$' + Math.floor(azureStoredApi) + ' / yr';
      amazonMobileApi.innerHTML = '$' + Math.floor(amazonStoredApi) + ' / yr';
      googleMobileApi.innerHTML = '$' + Math.floor(googleStoredApi) + ' / yr';
    });

    setTrackColors(dataApiStoredInput);
    dataApiStoredInput.style.borderRadius = '5px';

    setTrackColors(dataDownloadInput);
    dataDownloadInput.style.borderRadius = '5px';

    Chart.pluginService.register({
      afterDraw: function (chart) {
        var ctx = chart.chart.ctx;
        chart.data.datasets.forEach(function (dataset, datasetIndex) {
          var meta = chart.getDatasetMeta(datasetIndex);
          if (!meta.hidden) {
            meta.data.forEach(function (element, index) {
              // Set the border radius for each bar
              var barRadius = 10;
              var x = element._model.x;
              var y = element._model.y - 8;
              var width = element._model.width;
              var height = element._model.height;

              ctx.beginPath();
              ctx.moveTo(x - width / 2 + barRadius, y);
              ctx.lineTo(x + width / 2 - barRadius, y);
              ctx.quadraticCurveTo(x + width / 2, y, x + width / 2, y + barRadius);
              ctx.lineTo(x + width / 2, y + height - barRadius);
              ctx.quadraticCurveTo(x + width / 2, y + height, x + width / 2 - barRadius, y + height);
              ctx.lineTo(x - width / 2 + barRadius, y + height);
              ctx.quadraticCurveTo(x - width / 2, y + height, x - width / 2, y + height - barRadius);
              ctx.lineTo(x - width / 2, y + barRadius);
              ctx.quadraticCurveTo(x - width / 2, y, x - width / 2 + barRadius, y);
              ctx.closePath();

              if (index === 0) {
                ctx.fillStyle = 'rgba(96, 65, 211, 1)';
              } else {
                ctx.fillStyle = 'rgba(176, 170, 245, 1)';
              }
              ctx.fill();
            });
          }
        });
      },
    });

    let chartApi = new Chart(dataApiChart, {
      type: 'bar',
      data: {
        labels: ['Rabata Cloud Storage', 'Microsoft Azure', 'Amazon S3', 'Google Cloud'],
        datasets: [{
          data: [Math.floor(rabataStoredApi), Math.floor(azureStoredApi), Math.floor(amazonStoredApi), Math.floor(googleStoredApi)],
          borderWidth: 1,
          barRadius: 10, // Set the border radius value
          backgroundColor: [
            'rgba(96, 65, 211, 1)',
            'rgba(176, 170, 245, 1)',
            'rgba(176, 170, 245, 1)',
            'rgba(176, 170, 245, 1)',
          ],
          datalabels: {
            color: '#FFCE56',
          },
        }],
      },
      options: {
        legend: {
          display: false,
        },
        tooltips: {
          enabled: false,
        },
        'hover': {
          mode: null,
          'animationDuration': 0,
        },
        'animation': {
          'duration': 1,
          'onComplete': function () {
            var chartInstance = this.chart;

            ctx = chartInstance.ctx;
            ctx.font = '16px Gilroy';
            ctx.fillStyle = 'rgba(176, 170, 245, 1)';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';

            this.data.datasets.forEach(function (dataset, i) {
              let meta = chartInstance.controller.getDatasetMeta(i);
              if (isMobileDevice()) {
                meta.data.forEach(function (bar, index) {
                  let data = '$' + dataset.data[index] + ' / yr';
                  ctx.fillText(data, bar._model.x, bar._model.y - 15);
                });
              }
            });
          },
        },
        scales: {
          xAxes: [{
            ticks: {
              fontColor: 'rgba(176, 170, 245, 1)',
              fontSize: '16',
              display: isMobileDevice(),
            },
          }],
          yAxes: [{
            ticks: {
              fontColor: 'rgba(210, 210, 210, 1)',
              fontSize: '16',
              stepSize: roundedApi,
              max: roundedApi * 1.5,
            },
          }],
        },
      },
    });

    function redrawChart() {
      chartApi.options.scales.xAxes[0].display = isMobileDevice();
      chartApi.options.scales.xAxes[0].ticks.display = isMobileDevice();

      chartApi.options.scales.yAxes[0].display = !isMobileDevice();
      chartApi.options.scales.yAxes[0].ticks.display = !isMobileDevice();

      chartApi.resize();
      chartApi.update();
    }

    redrawChart();

    window.addEventListener('resize', redrawChart);
  }
});
