class FormValidation {
  constructor(formContainerId, submitCallback, options = { observeChanges: false, nativeSend: false }) {
    this.form = $(formContainerId);
    this.submitCallback = submitCallback;
    this.options = options;
    this.selectors = {
      field: '[data-validations]',
      fieldError: '.js-field-error-message',
      submitButton: '.js-submit-button',
      hint: '.js-input-hint',
    };
    this.classes = {
      valid: 'is-valid',
      error: 'is-error',
      disabled: 'btn-disabled',
      loading: 'is-loading',
      hidden: 'is-hidden',
    };
    this.messages = {
      required: TRANSLATIONS.en.forms.messages.required,
      email: TRANSLATIONS.en.forms.messages.email,
      password: TRANSLATIONS.en.forms.messages.password,
      passwordConfirm: TRANSLATIONS.en.forms.messages.passwordConfirm,
      accessKey: TRANSLATIONS.en.forms.messages.accessKey,
      bucketName: TRANSLATIONS.en.forms.messages.bucketName,
    };
    this.validations = {
      required: {
        test: (element, trimmedValue) => {
          if (element.attr('type') === 'checkbox') {
            return element.is(':checked');
          }

          return trimmedValue !== '';
        },
        errorMessage: this.messages.required,
      },
      email: {
        test: (element, trimmedValue) => {
          return /^[a-zA-Z0-9._–+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(trimmedValue);
        },
        errorMessage: this.messages.email,
      },
      password: {
        test: (element, trimmedValue) => {
          return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]).{8,}$/.test(trimmedValue);
        },
        errorMessage: this.messages.password,
      },
      passwordConfirm: {
        test: (element, trimmedValue) => {
          const password = this.form.find('[type="password"]').eq(0).val();

          return trimmedValue === password;
        },
        errorMessage: this.messages.passwordConfirm,
      },
      accessKey: {
        test: (element, trimmedValue, value) => {
          return /^(?=.{1,30}$)[a-zA-Z][a-zA-Z0-9-_]*$/.test(value);
        },
        errorMessage: this.messages.accessKey,
      },
      bucketName: {
        test: (element, trimmedValue, value) => {
          return /^[a-z0-9-]{2,60}[a-z0-9]$/.test(value);
        },
        errorMessage: this.messages.bucketName,
      },
    };
    this.fields = {};
    this.formData = {};

    this.init();

    this.form.data('validator', this);
  }

  setFormFields() {
    this.form.find(this.selectors.field).each((index, element) => {
      const field = $(element);
      const fieldId = field.attr('id');
      const fieldValidation = field.data('validations');
      let fieldValidationArray = null;

      if (!fieldValidation) {
        return;
      }

      fieldValidationArray = fieldValidation.split(' ');

      this.fields[fieldId] = {
        element: field,
        validations: fieldValidationArray,
        errorMessage: null,
        isValid: !fieldValidationArray.includes('required'),
        isRequired: fieldValidationArray.includes('required'),
        originalValue: field.val(),
      };

      this.formData[fieldId] = field.val();

      if (field.val() !== '' && !this.options.observeChanges) {
        this.validateField(field);
      }
    });
  }

  validateField(field) {
    const fieldId = field.attr('id');
    const fieldValidations = this.fields[fieldId].validations;
    const currentField = this.fields[fieldId];

    for (let i = 0; i < fieldValidations.length; i++) {
      const currentValidator = this.validations[fieldValidations[i]];
      const value = field.val();
      const trimmedValue = value.trim();

      if (!currentField.isRequired && trimmedValue === '') {
        currentField.isValid = true;
        currentField.errorMessage = null;

        currentField.element.removeClass(this.classes.error).removeClass(this.classes.valid);
        currentField.element.siblings(this.selectors.fieldError).text('');

        break;
      }

      if (!currentValidator.test(field, trimmedValue, value)) {
        this.fields[fieldId].errorMessage = currentValidator.errorMessage;

        currentField.isValid = false;
        currentField.element.removeClass(this.classes.valid).addClass(this.classes.error);
        currentField.element.siblings(this.selectors.fieldError).html(`<span>${currentValidator.errorMessage}</span>`);

        break;
      }

      if (currentField.element.siblings(this.selectors.hint).length > 0) {
        const isFieldChanged = currentField.originalValue !== currentField.element.val();

        currentField.element.siblings(this.selectors.hint).toggleClass(this.classes.hidden, !isFieldChanged || !currentField.isValid);
      }

      currentField.isValid = true;
      currentField.errorMessage = null;

      currentField.element.removeClass(this.classes.error).addClass(this.classes.valid);
      currentField.element.siblings(this.selectors.fieldError).text('');
    }
  }

  validateForm() {
    for (let fieldId in this.fields) {
      this.validateField(this.fields[fieldId].element);
    }
  }

  resetForm() {
    this.form.find(this.selectors.field).each((index, field) => {
      if ($(field).attr('type') === 'checkbox') {
        $(field).prop('checked', false);
      }

      $(field).val('');
      $(field).removeClass(this.classes.valid);
      $(field).removeClass(this.classes.error);
      $(field).siblings(this.selectors.fieldError).text('');
      $(field).siblings(this.selectors.hint).addClass(this.classes.hidden);
    });

    this.setFormFields();
  }

  observeChanges() {
    const isFormChanged = Object.values(this.fields).some((item) => item.originalValue !== item.element.val());

    if (!isFormChanged) {
      this.disableSubmitButton(true);
    } else {
      this.validateForm();
      this.disableSubmitButton(this.isFormHasErrors());
    }
  }

  disableSubmitButton(isValid) {
    this.form.find(this.selectors.submitButton).toggleClass(this.classes.disabled, isValid);
    this.form.find(this.selectors.submitButton).attr('disabled', isValid);
  }

  isFormHasErrors() {
    return Object.values(this.fields).some((item) => item.isValid === false);
  }

  setFormIsLoading(isLoading) {
    this.form.find(this.selectors.submitButton).toggleClass(this.classes.loading, isLoading);
  }

  bindEvents() {
    this.form.find(this.selectors.field).on('input', (event) => {
      const field = $(event.currentTarget);
      const fieldId = field.attr('id');

      this.validateField(field);
      this.formData[fieldId] = field.val();
    });

    this.form.on('input', () => {
      if (this.options.observeChanges) {
        this.observeChanges();

        return;
      }

      this.disableSubmitButton(this.isFormHasErrors());
    });

    this.form.on('submit', (event) => {
      if (this.options.nativeSend) {
        this.disableSubmitButton(true);
        this.setFormIsLoading(true);

        return;
      }

      event.preventDefault();

      this.validateForm();

      if (!this.isFormHasErrors()) {
        if (!this.submitCallback) {
          this.disableSubmitButton(true);
          this.setFormIsLoading(true);
          this.form[0].submit();

          return;
        }

        this.submitCallback(this.formData);
      }
    });

    const passwordField = Object.values(this.fields).find((item) => item.validations.includes('password'));
    const passwordConfirmField = Object.values(this.fields).find((item) => item.validations.includes('passwordConfirm'));

    if (passwordField && passwordConfirmField) {
      passwordField.element.on('input', () => {
        passwordConfirmField.element.siblings(this.selectors.errorMessage).addClass(this.classes.hidden);

        if (passwordConfirmField.element.val() !== '') {
          this.validateField(passwordConfirmField.element);
        }
      });

      passwordConfirmField.element.on('focus', () => {
        passwordConfirmField.element.siblings(this.selectors.errorMessage).removeClass(this.classes.hidden);

        if (!passwordField.isValid) {
          passwordConfirmField.element.siblings(this.selectors.errorMessage).addClass(this.classes.hidden);
          passwordField.element.focus();
        }
      });
    }

  }

  checkBackendErrors() {
    const errorsElement = this.form.find('[data-error-map]');

    errorsElement.each((index, item) => {
      const field = $(item).data('error-map');

      $(`[name="${field}"]`).addClass(this.classes.error);
    });

  }

  init() {
    this.setFormFields();
    this.bindEvents();
    this.disableSubmitButton(this.isFormHasErrors());
    this.checkBackendErrors();
  }
}

$(function() {
  new FormValidation('#login');
  new FormValidation('#registration');

  new FormValidation('#passwordUpdate', function(formData) {
    $.ajax({
      url: '/api/user/password',
      method: 'PUT',
      data: JSON.stringify(formData),
      headers: {
        'Content-Type': 'application/json',
      },
      beforeSend: () => {
        this.setFormIsLoading(true);
        this.disableSubmitButton(true);
      },
      success: () => {
        modalSuccess.show();

        this.setFormIsLoading(false);
        this.resetForm();
        this.bindEvents();
      },
      error: () => {
        modalError.show();

        this.setFormIsLoading(false);
        this.disableSubmitButton(this.isFormHasErrors());
      },
    });
  });

  new FormValidation('#settingsUpdate', function (formData) {
    $.ajax({
      url: '/api/user',
      method: 'PUT',
      data: JSON.stringify(formData),
      headers: {
        'Content-Type': 'application/json',
      },
      beforeSend: () => {
        this.setFormIsLoading(true);
        this.disableSubmitButton(true);
      },
      success: (data) => {
        this.setFormIsLoading(false);

        modalUserSettingsUpdate.hide();

        if (data.status === false) {
          modalError.show(data.message);

          return;
        }

        this.setFormFields();
        modalSuccess.show();

        $('[data-bind-value="userFullName"]').text(data.data.full_name);
        $('[data-bind-value="userEmail"]').text(data.data.email);
      },
      error: () => {
        this.setFormIsLoading(false);
        this.disableSubmitButton(this.isFormHasErrors());

        modalUserSettingsUpdate.hide();
        modalError.show();
      },
    });
  }, {
    observeChanges: true,
  });

  new FormValidation('#resetPasswordRequest', function (formData) {
    $.ajax({
      url: `/api/user/password/restore?email=${formData.email}`,
      method: 'GET',
      beforeSend: () => {
        this.setFormIsLoading(true);
        this.disableSubmitButton(true);
      },
      success: () => {
        this.setFormIsLoading(false);
        this.resetForm();

        modalResetPasswordForm.hide();
        modalResetPasswordSuccessMessage.show();
      },
      error: () => {
        this.setFormIsLoading(false);
        this.disableSubmitButton(this.isFormHasErrors());

        modalResetPasswordForm.hide();
        modalError.show();
      },
    });
  });

  new FormValidation('#resetPassword', function (formData) {
    const uuid = $('input[name="uuid"]').val();
    const token = $('input[name="token"]').val();

    $.ajax({
      url: `/api/user/password/restore/${uuid}`,
      method: 'POST',
      data: JSON.stringify({
        password: formData.password,
        token: token,
      }),
      headers: {
        'Content-Type': 'application/json',
      },
      beforeSend: () => {
        this.setFormIsLoading(true);
        this.disableSubmitButton(true);
      },
      success: () => {
        this.setFormIsLoading(false);
        this.resetForm();

        modalSuccess.show();

        setTimeout(() => {
          window.location.href = '/login';
        }, 3000);
      },
      error: () => {
        this.resetForm();
        this.setFormIsLoading(false);
        this.disableSubmitButton(this.isFormHasErrors());

        modalError.show();
      },
    });
  });

  new FormValidation('#createBucket', function (formData) {}, {
    nativeSend: true,
  });

  new FormValidation('#createAccessKey', function (formData) {}, {
    nativeSend: true,
  });
});
