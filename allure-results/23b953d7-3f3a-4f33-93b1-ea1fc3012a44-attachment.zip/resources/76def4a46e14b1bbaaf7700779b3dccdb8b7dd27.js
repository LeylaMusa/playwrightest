const TRANSLATIONS = {
  en: {
    forms: {
      messages: {
        required: 'This field is required',
        email: 'Please enter proper email',
        password: 'Password should contain at least 8 symbols and one capital letter, one special symbols like «$#%!_}{[]» and one number, for your security',
        passwordConfirm: 'Passwords do not match',
        accessKey: 'Access key can contain only letters of the Latin alphabet, numbers (0-9), as well as the «-» and «_» signs, the first character must be a letter',
        bucketName: 'Bucket name can contain up to 64 characters, the minimum number of characters is 3, contain only letters of the lowercase Latin alphabet, integer numbers (0-9), as well as the «-» sign',
      },
    },
    show: 'Show',
    hide: 'Hide',
    copy: 'Copy',
    copied: 'Copied',
  },
};
