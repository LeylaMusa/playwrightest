class Menu {
  constructor() {
    this.menu = $('.js-menu');
    this.menuItem = $('.js-menu-item');
    this.openMenuTrigger = $('.js-open-menu');
    this.closeMenuTrigger = $('.js-close-menu');

    this.init();
  }

  bindEvents() {
    this.openMenuTrigger.on('click', () => {
      this.menu.addClass('active');
    });

    this.closeMenuTrigger.on('click', () => {
      this.menu.removeClass('active');
    });

    this.menuItem.on('click', () => {
      this.menu.removeClass('active');
    });
  }

  init() {
    this.bindEvents();
  }
}

$(function () {
  new Menu();
});
