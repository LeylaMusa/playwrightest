document.addEventListener('DOMContentLoaded', () => {
  function isMobileDevice() {
    return window.innerWidth > 767;
  }

  const storageUrl = '/api/storage';
  const trafficUrl = '/api/traffic';

  fetch(storageUrl)
    .then(res => res.json())
    .then(out => storageDraw(out.data))
    .catch(err => {
      throw err;
    });

  fetch(trafficUrl)
    .then(res => res.json())
    .then(out => trafficDraw(out.data))
    .catch(err => {
      throw err;
    });

  let storageDraw = (data) => {
    const storageLineChart = document.getElementById('storage-chart-admin');
    const totalSpace = $('.total-space');

    const chartData = {
      type: 'line',
      data: {
        labels: data.labels,
        datasets: [{
          data: data.data,
          backgroundColor: [
            '#EFECFB',
          ],
          borderColor: [
            'rgba(96, 65, 211, 0.2)',
          ],
          borderWidth: 2,

          pointRadius: 0,
          pointHoverRadius: 8,
          pointBackgroundColor: 'rgba(96, 65, 211, 1)',
          pointBorderColor: 'rgba(96, 65, 211, 1)',

          tension: 0,
        }],
      },
      options: {
        legend: {
          display: false,
        },
        tooltips: {
          enabled: true,
          mode: 'nearest',
          intersect: false,
          callbacks: {
            label: function (tooltipItem, data) {
              let datasetIndex = tooltipItem.datasetIndex;
              let dataIndex = tooltipItem.index;
              let value = data.datasets[datasetIndex].data[dataIndex];
              return value + ' Mb';
            },
          },
        },
        scales: {
          xAxes: [{
            ticks: {
              fontColor: 'rgba(228, 228, 255, 1)',
              fontSize: '14',
              display: () => window.innerWidth > 767,
            },
          }],
          yAxes: [{
            type: 'linear',
            position: 'left',
            gridLines: {
              borderDash: [5, 5], // Dashed grid lines on x-axis
            },
            ticks: {
              fontColor: 'rgba(228, 228, 255, 1)',
              fontSize: '14',
              beginAtZero: true,
            },
          }],
        },
      },
    };
    let chartStorage;

    function initStorageLineChart() {
      if (storageLineChart) {
        chartStorage = new Chart(storageLineChart, chartData);
      }
    }

    initStorageLineChart();

    window.addEventListener('resize', function() {
      if (chartStorage) {
        chartStorage.destroy();
      }

      initStorageLineChart();
    });

    totalSpace.text(data.current);
  };

  let trafficDraw = (data) => {
    const storageLineChart = document.getElementById('traffic-chart-admin');
    const totalIncoming = $('.total-incoming');
    const totalOutgoing = $('.total-outgoing');

    const chartData = {
      type: 'line',
      data: {
        labels: data.labels,
        datasets: [
          {
            data: data.outgoing,

            backgroundColor: [
              '#DBF3F3',
            ],
            borderColor: [
              'rgba(75, 192, 192, 0.4)',
            ],
            borderWidth: 2,

            pointRadius: 0,
            pointHoverRadius: 8,
            pointBackgroundColor: 'rgba(12, 203, 141, 1)',
            pointBorderColor:  'rgba(12, 203, 141, 0.1)',

            tension: 0,
          },
          {
            data: data.incoming,

            backgroundColor: [
              '#EFECFB',
            ],
            borderColor: [
              'rgba(96, 65, 211, 0.2)',
            ],
            borderWidth: 2,

            pointRadius: 0,
            pointHoverRadius: 8,
            pointBackgroundColor: 'rgba(96, 65, 211, 1)',
            pointBorderColor: 'rgba(153, 102, 255, 0.1)',

            tension: 0,
          },
        ],
      },
      options: {
        legend: {
          display: false,
        },
        tooltips: {
          mode: 'nearest', // Show only one tooltip on hover
          enabled: true,
          intersect: false,
          callbacks: {
            label: function(tooltipItem, data) {
              let datasetIndex = tooltipItem.datasetIndex;
              let dataIndex = tooltipItem.index;
              let value = data.datasets[datasetIndex].data[dataIndex];
              return value + ' Mb';
            },
          },
        },
        scales: {
          xAxes: [{
            ticks: {
              fontColor: 'rgba(228, 228, 255, 1)',
              fontSize: '14',
              display: isMobileDevice(),
            },
          }],
          yAxes: [{
            type: 'linear',
            position: 'left',
            gridLines: {
              borderDash: [5, 5], // Dashed grid lines on x-axis
            },
            ticks: {
              fontColor: 'rgba(228, 228, 255, 1)',
              fontSize: '14',
              beginAtZero:true,
            },
          }],
        },
      },
    };

    let chartStorage;

    function initLineChart() {
      if (storageLineChart) {
        chartStorage = new Chart(storageLineChart, chartData);
      }
    }

    initLineChart();

    window.addEventListener('resize', function() {
      if (chartStorage) {
        chartStorage.destroy();
      }

      initLineChart();
    });

    totalIncoming.text(data.totalIncoming);
    totalOutgoing.text(data.totalOutgoing);
  };
});
