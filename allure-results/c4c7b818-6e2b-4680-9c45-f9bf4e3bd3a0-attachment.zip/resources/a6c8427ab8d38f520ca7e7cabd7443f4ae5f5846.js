document.addEventListener('DOMContentLoaded', () => {
  const showSecretBtn = document.getElementById('toggleSecret');
  const secretKeyInput = document.getElementById('secretKey');

  if (showSecretBtn) {
    showSecretBtn.addEventListener('click', () => {
      secretKeyInput.classList.toggle('hidden');

      let text = showSecretBtn.innerHTML;

      if (text === TRANSLATIONS.en.show) {
        showSecretBtn.innerHTML = TRANSLATIONS.en.hide;
      } else {
        showSecretBtn.innerHTML = TRANSLATIONS.en.show;
      }
    });
  }

  const paymentBtns = document.querySelectorAll('.checkbox-wrap.switch');
  const paymentRows = document.querySelectorAll('.table-payment .row');

  if (paymentBtns) {
    paymentBtns.forEach((item) => {
      let type = item.dataset.type;

      item.addEventListener('click', () => {
        paymentRows.forEach((row) => {
          if (row.classList.contains(type)) {
            row.classList.remove('active');
          }
        });

        item.parentElement.classList.add('active');
      });
    });
  }

  const sepaBtn = document.getElementById('sepaBtn');
  const creditBtn = document.getElementById('cardBtn');
  const sepaTable = document.getElementById('sepaTable');
  const creditTable = document.getElementById('creditTable');
  const sepaToggle = document.querySelector('#sepaBtn .toggle');
  const creditToggle = document.querySelector('#cardBtn .toggle');

  const sepaFormBtn = document.getElementById('sepaFormBtn');
  const creditFormBtn = document.getElementById('cardFormBtn');
  const sepaForm = document.getElementById('sepaForm');
  const creditForm = document.getElementById('creditForm');
  const sepaFormToggle = document.querySelector('#sepaFormBtn .toggle');
  const creditFormToggle = document.querySelector('#cardFormBtn .toggle');

  if (sepaToggle) {
    sepaToggle.addEventListener('click', () => {
      sepaBtn.classList.add('active');
      creditBtn.classList.remove('active');
      sepaTable.style.display = 'block';
      creditTable.style.display = 'none';
    });

  }

  if (creditToggle) {
    creditToggle.addEventListener('click', () => {
      creditBtn.classList.add('active');
      sepaBtn.classList.remove('active');
      creditTable.style.display = 'block';
      sepaTable.style.display = 'none';
    });
  }

  if (sepaFormToggle) {
    sepaFormToggle.addEventListener('click', () => {
      sepaFormBtn.classList.add('active');
      creditFormBtn.classList.remove('active');
      sepaForm.style.display = 'block';
      creditForm.style.display = 'none';
    });
  }

  if (creditFormToggle) {
    creditFormToggle.addEventListener('click', () => {
      creditFormBtn.classList.add('active');
      sepaFormBtn.classList.remove('active');
      creditForm.style.display = 'block';
      sepaForm.style.display = 'none';
    });
  }

  let doughnutChart = document.getElementById('doughnut-chart');
  let newDoughnutChart;

  function initializeDoughnutChart() {
    if (doughnutChart) {
      newDoughnutChart = new Chart(doughnutChart, {
        type: 'doughnut',
        data: {
          labels: ['Traffic', 'Storage'],
          datasets: [
            {
              data: [$('#traffic-price').data('value'), $('#storage-price').data('value')],
              backgroundColor: ['#0CCB8D', '#6041D3'],
              hoverBackgroundColor: ['#FF6384', '#36A2EB'],
            },
          ],
        },
        options: {
          responsive: true,
          cutoutPercentage: 85,
          legend: {
            display: false,
          },
        },
      });
    }
  }

  initializeDoughnutChart();

  window.addEventListener('resize', function () {
    if (newDoughnutChart) {
      newDoughnutChart.destroy();
    }
    initializeDoughnutChart();
  });

});

function toClipboard(el) {
  navigator.clipboard.writeText(el.previousSibling.previousSibling.value);

  $('.js-copy-text').text(TRANSLATIONS.en.copy);
  $(el).find('.js-copy-text').text(TRANSLATIONS.en.copied);
}
