class ShowMore {
  constructor() {
    this.selectors = {
      showMoreButton: '.js-show-more',
      showMoreDropdown: '.js-dropdown',
    };
    this.classes = {
      hidden: 'is-hidden',
    };

    this.init();
  }

  bindEvents() {
    $(this.selectors.showMoreButton).on('click', (event) => {
      event.preventDefault();

      if ($(event.currentTarget).siblings(this.selectors.showMoreDropdown).hasClass(this.classes.hidden)) {
        $(this.selectors.showMoreDropdown).addClass(this.classes.hidden);
      }

      $(event.currentTarget).siblings(this.selectors.showMoreDropdown).toggleClass(this.classes.hidden);
    });

    $(document).on('click', (event) => {
      if (!$(event.target).closest(this.selectors.showMoreButton).length) {
        $(this.selectors.showMoreDropdown).addClass(this.classes.hidden);
      }
    });
  }

  init() {
    this.bindEvents();
  }
}

$(function () {
  new ShowMore();
});
